package sn.isi.projetandroid;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class AfficheCvActivity extends AppCompatActivity {
    private ListView Listes;
    private ProgressDialog dialog;
    String nom;
    ArrayList<HashMap<String,String>> listecv = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_affiche_cv);

        Listes = findViewById(R.id.Listes);
        dialog = new ProgressDialog(this);
        dialog.setMessage("Wait please");
        nom= getIntent().getStringExtra("Nom");
        String url ="http://192.168.1.3:10080/emploie/listecv.php?nom="+nom;
        ReseachServer is = new ReseachServer();
        is.execute(url);
    }
    protected class ReseachServer extends AsyncTask<String, Void, String>
    {
        @Override
        protected void onPreExecute() {
            dialog.show();

        }

        @Override
        protected String doInBackground(String...urls) {
            try {
                HttpClient client = new DefaultHttpClient();
                HttpGet get = new HttpGet(urls[0]);
                ResponseHandler<String> buffer = new BasicResponseHandler();
                String result = client.execute(get, buffer);
                return result;

            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            dialog.dismiss();
            try {
                if(result==null)
                    Toast.makeText(AfficheCvActivity.this, "Erreur connection", Toast.LENGTH_SHORT).show();
                else {
                    JSONObject jObj = new JSONObject(result);
                    JSONArray jArr = jObj.getJSONArray("marks");
                    for (int i = 0; i <jArr.length(); i++) {
                        jObj=jArr.getJSONObject(i);
                        String nom=jObj.getString("nom");
                        String prenom=jObj.getString("prenom");
                        String age=jObj.getString("age");
                        String situation=jObj.getString("situation");
                        String diplome=jObj.getString("diplome");
                        HashMap<String,String> map =new HashMap<>();
                        map.put("nom",nom);
                        map.put("prenom",prenom);
                        map.put("age",age);
                        map.put("situation",situation);
                        map.put("diplome",diplome);
                        listecv.add(map);

                    }

                }


            }
            catch (Exception e)
            {
                e.printStackTrace();
                Toast.makeText(AfficheCvActivity.this, e.getMessage(), Toast.LENGTH_SHORT);

            }
            ListAdapter adapter = new SimpleAdapter(AfficheCvActivity.this,listecv,R.layout.items, new String[]{"nom","prenom","age","situation","diplome"},new int[]{R.id.txtNom1,R.id.txtPrenom1,R.id.txtAge,R.id.txtSituation,R.id.txtDiplome});
            Listes.setAdapter(adapter);

        }
    }



}

