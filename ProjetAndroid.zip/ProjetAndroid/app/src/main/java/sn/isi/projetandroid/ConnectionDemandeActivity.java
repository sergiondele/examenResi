package sn.isi.projetandroid;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONObject;

public class ConnectionDemandeActivity extends AppCompatActivity {
    private EditText txtLogin1, txtpassword1;
    private Button btnConnection1, btnInscription1;
    private String login1, password1;
    private ProgressDialog dialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_connection_demande);
        dialog = new ProgressDialog(this);
        dialog.setMessage("Wait");
        txtLogin1 = findViewById(R.id.txtLogin1);
        txtpassword1 = findViewById(R.id.txtPassword1);
        btnConnection1 = findViewById(R.id.btnConnection1);
        btnInscription1 = findViewById(R.id.btnInscription1);
        btnConnection1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                login1 = txtLogin1.getText().toString();
                password1 = txtpassword1.getText().toString();
                if (login1.isEmpty() || password1.isEmpty()) {
                    String message = "Erreur champs";
                    Toast.makeText(ConnectionDemandeActivity.this, message, Toast.LENGTH_SHORT).show();

                } else {
                    //Intent intent = new Intent(ConnectionDemandeActivity.this, DemandeurActivity.class);
                    // startActivity(intent);
                    String url = "http://10.0.2.2/emploie/connexiondemandeur.php?login1=" + login1 + "&password1=" + password1;
                    LoginServer ls = new LoginServer();
                    ls.execute(url);

                }


            }
        });
        btnInscription1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ConnectionDemandeActivity.this, InscriptionDemandeurActivity.class);
                startActivity(intent);
            }
        });
    }

    protected class LoginServer extends AsyncTask<String, Void, String> {
        @Override
        protected void onPreExecute() {
            dialog.show();

        }

        @Override
        protected String doInBackground(String... urls) {
            try {
                HttpClient client = new DefaultHttpClient();
                HttpGet get = new HttpGet(urls[0]);
                ResponseHandler<String> buffer = new BasicResponseHandler();
                String result = client.execute(get, buffer);
                return result;

            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            dialog.dismiss();
            try {
                if (result == null)
                    Toast.makeText(ConnectionDemandeActivity.this, "Erreur connection", Toast.LENGTH_SHORT).show();
                else {
                    JSONObject jo = new JSONObject(result);
                    String status = jo.getString("status");
                    if (status.equalsIgnoreCase("KO"))
                        Toast.makeText(ConnectionDemandeActivity.this, "Erreur parametres", Toast.LENGTH_SHORT).show();
                    else {
                        Intent intent = new Intent(ConnectionDemandeActivity.this, DemandeurActivity.class);
                        intent.putExtra("LOGIN", login1);
                        startActivity(intent);
                    }

                }


            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }
}

