package sn.isi.projetandroid;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONObject;

public class ConnectionOffreActivity extends AppCompatActivity {
    private EditText txtLogin, txtpassword;
    private Button btnConnection, btnInscription;
    private String login, password;
    private ProgressDialog dialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_connection_offre);
        dialog = new ProgressDialog(this);
        dialog.setMessage("Wait");
        txtLogin = findViewById(R.id.txtLogin);
        txtpassword = findViewById(R.id.txtPassword);
        btnConnection = findViewById(R.id.btnConnection);
        btnInscription = findViewById(R.id.btnInscription);
        btnConnection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                login = txtLogin.getText().toString();
                password= txtpassword.getText().toString();
                if(login.isEmpty()      || password.isEmpty())
                {
                    String message = "Erreur champs";
                    Toast.makeText(ConnectionOffreActivity.this, message, Toast.LENGTH_SHORT).show();

                }else{
                    // Intent intent = new Intent(ConnectionOffreActivity.this, OffreActivity.class);
                    // startActivity(intent);
                    String url ="http://10.0.2.2/emploie/connexionoffre.php?login="+login+"&password="+password;
                    LoginServer ls =new LoginServer();
                    ls.execute(url);

                }


            }
        });
        btnInscription.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ConnectionOffreActivity.this, InscriptionActivity.class);
                startActivity(intent);
            }
        });
    }
    protected class LoginServer extends AsyncTask<String, Void, String>
    {
        @Override
        protected void onPreExecute() {
            dialog.show();

        }

        @Override
        protected String doInBackground(String...urls) {
            try {
                HttpClient client = new DefaultHttpClient();
                HttpGet get = new HttpGet(urls[0]);
                ResponseHandler<String> buffer = new BasicResponseHandler();
                String result = client.execute(get, buffer);
                return result;

            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            dialog.dismiss();
            try {
                if(result==null)
                    Toast.makeText(ConnectionOffreActivity.this,"Erreur connection", Toast.LENGTH_SHORT).show();
                else {
                    JSONObject jo = new JSONObject(result);
                    String status = jo.getString("status");
                    if(status.equalsIgnoreCase("KO"))
                        Toast.makeText(ConnectionOffreActivity.this, "Erreur parametres", Toast.LENGTH_SHORT).show();
                    else {
                        Intent intent = new Intent(ConnectionOffreActivity.this, OffreActivity.class);
                        intent.putExtra("LOGIN", login);
                        startActivity(intent);
                    }

                }


            }
            catch (Exception e)
            {
                e.printStackTrace();
            }

        }
    }






}

