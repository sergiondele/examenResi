package sn.isi.projetandroid;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class DemandeurActivity extends AppCompatActivity {
    private Button btnLsoffre,btnModifier;
    private String login;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demandeur);
        login= getIntent().getStringExtra("LOGIN");
        btnLsoffre=findViewById(R.id.btnLsoffre);
        btnModifier=findViewById(R.id.btnModifier);
        btnLsoffre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DemandeurActivity.this, ListeOffreActivity.class);
                intent.putExtra("LOGIN", login);
                startActivity(intent);
            }
        });

        btnModifier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
    }


}

