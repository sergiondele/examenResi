package sn.isi.projetandroid;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class InscriptionActivity extends AppCompatActivity {
    private EditText txtLogin,txtPassword,txtNom;
    private String login,password,nom;
    private Button btnEnvoyer;
    private ProgressDialog dialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inscription);
        dialog = new ProgressDialog(this);
        dialog.setMessage("patientez svp");
        txtLogin=findViewById(R.id.txtLogin);
        txtNom=findViewById(R.id.txtNom);
        txtPassword=findViewById(R.id.txtPassword);
        btnEnvoyer=findViewById(R.id.btnEnvoyer);
        btnEnvoyer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nom= txtNom.getText().toString();
                login=txtLogin.getText().toString();
                password=txtPassword.getText().toString();
                String url ="http://10.0.2.2/emploie/inscriptionoffre.php";
                InscriptionServer is = new InscriptionServer();
                is.execute(url);
            }
        });
    }
    protected class InscriptionServer extends AsyncTask<String, Void, String>
    {
        @Override
        protected void onPreExecute() {
            dialog.show();

        }

        @Override
        protected String doInBackground(String...urls) {
            try {

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(urls[0]);
                List<NameValuePair> form = new ArrayList<>();
                form.add(new BasicNameValuePair("nom", nom));
                form.add(new BasicNameValuePair("login", login));
                form.add(new BasicNameValuePair("password", password));
                post.setEntity(new UrlEncodedFormEntity(form, HTTP.UTF_8));
                ResponseHandler<String> buffer = new BasicResponseHandler();
                String result = client.execute(post, buffer);
                return result;

            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            dialog.dismiss();
            try {
                if(result==null)
                    Toast.makeText(InscriptionActivity.this, "problÃ¨me connection", Toast.LENGTH_SHORT).show();
                else {
                    JSONObject jo = new JSONObject(result);
                    String status = jo.getString("status");
                    if(status.equalsIgnoreCase("KO"))
                        Toast.makeText(InscriptionActivity.this, "Enregistrement Ã©chouÃ©", Toast.LENGTH_SHORT).show();
                    else {
                        Intent intent = new Intent(InscriptionActivity.this, AcceuilActivity.class);
                        startActivity(intent);
                        Toast.makeText(InscriptionActivity.this,"Enregistrement reussi", Toast.LENGTH_SHORT).show();
                    }

                }


            }
            catch (Exception e)
            {
                e.printStackTrace();
            }

        }
    }


}

