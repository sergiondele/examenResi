package sn.isi.projetandroid;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class InscriptionDemandeurActivity extends AppCompatActivity {
    private EditText txtLogin1,txtPassword1,txtPrenom,txtNom,txtAge,txtStm,txtDob;
    private String login1,password1,nom,prenom,age,situation,diplome;
    private Button btnEnvoyer;
    private ProgressDialog dialog;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inscription_demandeur);
        dialog = new ProgressDialog(this);
        dialog.setMessage("patientez svp");
        txtLogin1=findViewById(R.id.txtLogin1);
        txtPrenom=findViewById(R.id.txtPrenom);
        txtNom=findViewById(R.id.txtNom);
        txtAge=findViewById(R.id.txtAge);
        txtStm=findViewById(R.id.txtStm);
        txtDob=findViewById(R.id.txtDob);
        txtPassword1=findViewById(R.id.txtPassword1);
        btnEnvoyer=findViewById(R.id.btnEnvoyer);
        btnEnvoyer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                login1=txtLogin1.getText().toString();
                nom=txtNom.getText().toString();
                prenom=txtPrenom.getText().toString();
                age=txtAge.getText().toString();
                situation=txtStm.getText().toString();
                diplome=txtDob.getText().toString();
                password1=txtPassword1.getText().toString();
                String url ="http://10.0.2.2/emploie/inscriptiondemande.php";
                InscriptionServer1 is = new InscriptionServer1();
                is.execute(url);
            }
        });
    }
    protected class InscriptionServer1 extends AsyncTask<String, Void, String>
    {
        @Override
        protected void onPreExecute() {
            dialog.show();

        }

        @Override
        protected String doInBackground(String...urls) {
            try {

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(urls[0]);
                List<NameValuePair> form = new ArrayList<>();
                form.add(new BasicNameValuePair("login1", login1));
                form.add(new BasicNameValuePair("password1", password1));
                form.add(new BasicNameValuePair("nom", nom));
                form.add(new BasicNameValuePair("prenom", prenom));
                form.add(new BasicNameValuePair("age", age));
                form.add(new BasicNameValuePair("situation", situation));
                form.add(new BasicNameValuePair("diplome", diplome));
                post.setEntity(new UrlEncodedFormEntity(form, HTTP.UTF_8));
                ResponseHandler<String> buffer = new BasicResponseHandler();
                String result = client.execute(post, buffer);
                return result;

            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            dialog.dismiss();
            try {
                if(result==null)
                    Toast.makeText(InscriptionDemandeurActivity.this, "problÃ¨me connection", Toast.LENGTH_SHORT).show();
                else {
                    JSONObject jo = new JSONObject(result);
                    String status = jo.getString("status");
                    if(status.equalsIgnoreCase("KO"))
                        Toast.makeText(InscriptionDemandeurActivity.this, "Enregistrement Ã©chouÃ©", Toast.LENGTH_SHORT).show();
                    else {
                        Intent intent = new Intent(InscriptionDemandeurActivity.this, AcceuilActivity.class);
                        startActivity(intent);
                        Toast.makeText(InscriptionDemandeurActivity.this,"Enregistrement reussi", Toast.LENGTH_SHORT).show();
                    }

                }


            }
            catch (Exception e)
            {
                e.printStackTrace();
            }

        }
    }


}

