package sn.isi.projetandroid;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class OffreActivity extends AppCompatActivity {
    private Button btnCv,btnAjoffre,btnLsoffre;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_offre);
        btnCv=findViewById(R.id.btnCv);
        btnAjoffre=findViewById(R.id.btnAjoffre);
        btnLsoffre=findViewById(R.id.btnLsoffre);
        btnCv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(OffreActivity.this, CvActivity.class);
                startActivity(intent);

            }
        });
        btnLsoffre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(OffreActivity.this, ListeOffreActivity.class);
                startActivity(intent);
            }
        });
        btnAjoffre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(OffreActivity.this, AjoutOffreActivity.class);
                startActivity(intent);
            }
        });
    }

}

