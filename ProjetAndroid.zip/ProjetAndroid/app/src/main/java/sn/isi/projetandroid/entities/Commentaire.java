package sn.isi.projetandroid.entities;

public class Commentaire {
    private int id;
    private String libelle;
    private Demandeur demandeur;
    private Offres offres;

    public Commentaire() {
    }

    public Commentaire(int id, String libelle, Demandeur demandeur, Offres offres) {
        this.id = id;
        this.libelle = libelle;
        this.demandeur = demandeur;
        this.offres = offres;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public Demandeur getDemandeur() {
        return demandeur;
    }

    public void setDemandeur(Demandeur demandeur) {
        this.demandeur = demandeur;
    }

    public Offres getOffres() {
        return offres;
    }

    public void setOffres(Offres offres) {
        this.offres = offres;
    }
}
