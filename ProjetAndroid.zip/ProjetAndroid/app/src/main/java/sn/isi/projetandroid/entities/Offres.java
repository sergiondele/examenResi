package sn.isi.projetandroid.entities;

public class Offres {
    private int id;
    private String date;
    private String libelle;
    private Entreprise entreprise;
    private Domaine domaine;

    public Offres() {
    }

    public Offres(int id, String date, String libelle, Entreprise entreprise, Domaine domaine) {
        this.id = id;
        this.date = date;
        this.libelle = libelle;
        this.entreprise = entreprise;
        this.domaine = domaine;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public Entreprise getEntreprise() {
        return entreprise;
    }

    public void setEntreprise(Entreprise entreprise) {
        this.entreprise = entreprise;
    }

    public Domaine getDomaine() {
        return domaine;
    }

    public void setDomaine(Domaine domaine) {
        this.domaine = domaine;
    }
}
