package sn.isi.projetandroid.entities;

public class OffresDemandeur {
    private int id;
    private Offres offres;
    private Demandeur demandeur;

    public OffresDemandeur() {
    }

    public OffresDemandeur(int id, Offres offres, Demandeur demandeur) {
        this.id = id;
        this.offres = offres;
        this.demandeur = demandeur;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Offres getOffres() {
        return offres;
    }

    public void setOffres(Offres offres) {
        this.offres = offres;
    }

    public Demandeur getDemandeur() {
        return demandeur;
    }

    public void setDemandeur(Demandeur demandeur) {
        this.demandeur = demandeur;
    }
}
